/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import controladores.EmpleadoJpaController;
import entidades.Empleado;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SDH
 */
public class JpaServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, NamingException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //  processRequest(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   
       /* 
// testear
     
    // Obtener los datos del formulario
        String codigo = request.getParameter("codigo");
        String nombre = request.getParameter("nombre");
        String profesion = request.getParameter("profesion");
        String empresa = request.getParameter("empresa");

        // Crear un nuevo objeto Empleado con los datos recibidos
        Empleado empleado = new Empleado();
        empleado.setCodigo(codigo);
        empleado.setNombre(nombre);
        empleado.setProfesion(profesion);
        empleado.setEmpresa(empresa);

        try {
            // Usar el EmpleadoJpaController para persistir los datos
            EmpleadoJpaController empleadoController = new EmpleadoJpaController();
            empleadoController.create(empleado);

            // Redirigir a una página de éxito
            response.sendRedirect("exito.jsp");

        } catch (NamingException ex) {
            ex.printStackTrace();
            response.sendRedirect("error.jsp");
        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("error.jsp");
        }
        
        */
        
        
        // ESTE ES EL OBJETO DE LA CLASE CONTROLLER 
     EmpleadoJpaController empleadoController = null;

    try {
        empleadoController = new EmpleadoJpaController();
    } catch (NamingException ex) {
        Logger.getLogger(JpaServlet.class.getName()).log(Level.SEVERE, null, ex);
    }

    String accion = request.getParameter("accion");

    if ("agregar".equals(accion) || "enviar".equals(accion)) {
        // Obtener los datos del formulario
        String codigo = request.getParameter("codigo");
        String nombre = request.getParameter("nombre");
        String profesion = request.getParameter("profesion");
        String empresa = request.getParameter("empresa");

        // Crear un nuevo objeto Empleado con los datos recibidos
        Empleado empleado = new Empleado();
        empleado.setCodigo(codigo);
        empleado.setNombre(nombre);
        empleado.setProfesion(profesion);
        empleado.setEmpresa(empresa);

        try {
            empleadoController.create(empleado);
            // Pasar un mensaje de éxito a la vista sin redirigir
            request.setAttribute("mensaje", "Empleado agregado exitosamente.");
        } catch (Exception ex) {
            ex.printStackTrace();
            request.setAttribute("mensaje", "Error al agregar el empleado.");
        }
    } else if ("actualizar".equals(accion)) {
        String codigo = request.getParameter("codigo");
        String nombre = request.getParameter("nombre");
        String profesion = request.getParameter("profesion");
        String empresa = request.getParameter("empresa");

        // Crear un objeto Empleado existente
        Empleado empleado = new Empleado(codigo);
        empleado.setNombre(nombre);
        empleado.setProfesion(profesion);
        empleado.setEmpresa(empresa);

        try {
            empleadoController.edit(empleado);
            request.setAttribute("mensaje", "Empleado actualizado exitosamente.");
        } catch (Exception ex) {
            ex.printStackTrace();
            request.setAttribute("mensaje", "Error al actualizar el empleado.");
        }
    } else if ("borrar".equals(accion)) {
        String codigo = request.getParameter("codigo");

        try {
            empleadoController.destroy(codigo);
            request.setAttribute("mensaje", "Empleado borrado exitosamente.");
        } catch (Exception ex) {
            ex.printStackTrace();
            request.setAttribute("mensaje", "Error al borrar el empleado.");
        }
    }

    
    List<Empleado> listaEmpleados = empleadoController.findEmpleadoEntities();
    request.setAttribute("listaDatos", listaEmpleados);

    // Enviar los datos a mostrarDatos.jsp
    request.getRequestDispatcher("mostrarDatos.jsp").forward(request, response);
 
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
